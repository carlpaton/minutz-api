﻿namespace tzatziki.minutz
{
  public enum RoleEnum
  {
    Attendee,
    User,
    Admin
  }
}

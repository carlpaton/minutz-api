﻿using tzatziki.minutz.models.Database;

namespace tzatziki.minutz.models
{
	public class AppSettings
	{
		public string DefaultProfilePicture { get; set; }

		public ConnectionStrings ConnectionStrings { get; set; }
	}
}

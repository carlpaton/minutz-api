﻿namespace tzatziki.minutz.models
{
  public class MeetingModel
  {
  }
}
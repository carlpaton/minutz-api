﻿

namespace tzatziki.minutz.models
{
    public class DashboardModel
    {
    }
}

﻿
using tzatziki.minutz.models.Auth;

namespace tzatziki.minutz.models
{
	public class BaseModel
	{
		public UserProfile User { get; set; }
	}
}

﻿namespace tzatziki.minutz.models.Database
{
  public class ConnectionStrings
  {
    public string DevelopmentConnection { get; set; }
    public string LiveConnection { get; set; }

    public string AzureConnection { get; set; }
  }
}
﻿
namespace tzatziki.minutz.models.Auth
{
  public class AppMetadata
  {
    public string Role { get; set; }
  }
}

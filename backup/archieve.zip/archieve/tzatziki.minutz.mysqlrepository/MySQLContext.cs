﻿using Microsoft.EntityFrameworkCore;


namespace tzatziki.minutz.mysqlrepository
{
	//public static class DBConnectorContextFactory
	//{
	//	public static DBConnectorContext Create(string connectionString)
	//	{
	//		var optionsBuilder = new DbContextOptionsBuilder<DBConnectorContext>();
	//		optionsBuilder.UseMySQL(connectionString);
	//		var context = new DBConnectorContext(optionsBuilder.Options);
	//		context.Database.EnsureCreated();
	//		return context;
	//	}
	//}
}

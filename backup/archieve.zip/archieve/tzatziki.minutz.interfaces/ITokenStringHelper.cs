﻿using System;

namespace tzatziki.minutz.interfaces
{
	public interface ITokenStringHelper
	{
		DateTime ConvertTokenStringToDate(string tokenValue);
	}
}

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace tzatziki.minutz.auth0.repository.tests
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestMethod1()
    {
     // new tzatziki.minutz.auth0.service.Repository().TestAsync("google-oauth2|117785067536320807071", "tzatziki-minutz.auth0.com", "3_ji0JgkrygjDWRkJtYGcrv5TN9eIsoZAbKi7bmkKiUqwpo3lOryhaMvOTlZRSDZ").GetAwaiter();
    }
  }
}
//"Auth0": {
//		"Domain": "tzatziki-minutz.auth0.com",
//		"ClientId": "spEQucIOEbSBvkixqRHzkKDHNYRaGy3J",
//		"ClientSecret": "3_ji0JgkrygjDWRkJtYGcrv5TN9eIsoZAbKi7bmkKiUqwpo3lOryhaMvOTlZRSDZ",
//		"CallbackUrl": "http://localhost:60856/signin-auth0"
//	},